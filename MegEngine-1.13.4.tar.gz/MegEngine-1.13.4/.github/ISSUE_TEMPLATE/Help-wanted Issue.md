---
name: Help-wanted Issue
about: 请使用此模板提出help-wanted任务
title: Help-wanted Issue
labels: ''
assignees: ''

---

## 背景
<!-- 请简要描述此需求的背景 -->
<!-- 示例：Googlenet是ImageNet挑战赛(ILSVRC14)第一名的高性能网络结构，常用分类模型之一。MegEngine已经提供相关的OPR支持 -->

## 任务描述
<!-- 请详细描述该任务，任务需要明确、具体 -->
<!-- 示例：Googlenet模型复现，训练正常收敛，验收指标符合预期，并将代码提交到models/vision/classification/models[contribution] 下-->

## 目标
<!-- 请明确此任务的目标 -->
<!-- 示例：数据集ImageNet 对点和论文一致 -->
