---
name: Feature Request
about: 请使用此模板提出您的建议
title: Feature Request
labels: ''
assignees: ''

---

<!-- 请简介清晰的描述您的需求 -->

## 背景
<!-- 请简单描述您将在什么场景下需要这个功能 -->

## 需求描述
<!-- 请详细描述您的需求并给出验收目标 -->
