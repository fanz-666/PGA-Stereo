#!/bin/bash -e


function log() {
    d=$(date +'%Y-%m-%d %H:%M:%S')
    echo $d" "$1
}