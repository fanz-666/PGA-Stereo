#include "src/arm_common/simd_macro/neon_helper.h"

#include "src/common/pooling/do_max_pooling_3x3_s2x2_float_def.inl"

#include "src/arm_common/simd_macro/neon_helper_epilogue.h"
