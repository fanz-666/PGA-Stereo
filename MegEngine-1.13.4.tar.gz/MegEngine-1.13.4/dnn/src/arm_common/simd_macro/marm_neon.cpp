#include "src/arm_common/simd_macro/marm_neon.h"

#pragma message \
        "remove these functions defined in march_neon.h when these functions defined in the future compiler(arm_neon.h)"
