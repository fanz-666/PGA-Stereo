#include "src/arm_common/conv_bias/int8/direct_kernels/int8_direct_nchw_nchw44_s1.h"
using namespace megdnn;
using namespace arm_common;

INSTANCE_CONV_KERN(1, 1);

// vim: syntax=cpp.doxygen
