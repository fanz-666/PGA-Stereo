#include "src/arm_common/conv_bias/int8/direct_kernels/dot_direct_nchw44_s2.h"
#if MGB_ENABLE_DOT
using namespace megdnn;
using namespace arm_common;

FOR_BIAS(2, 7);

#endif
// vim: syntax=cpp.doxygen
