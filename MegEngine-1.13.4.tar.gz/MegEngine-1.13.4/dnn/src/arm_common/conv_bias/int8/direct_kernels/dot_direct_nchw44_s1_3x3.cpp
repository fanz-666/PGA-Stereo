#include "src/arm_common/conv_bias/int8/direct_kernels/dot_direct_nchw44_s1.h"
#if MGB_ENABLE_DOT
using namespace megdnn;
using namespace arm_common;

FOR_BIAS(1, 3);

#endif
// vim: syntax=cpp.doxygen
