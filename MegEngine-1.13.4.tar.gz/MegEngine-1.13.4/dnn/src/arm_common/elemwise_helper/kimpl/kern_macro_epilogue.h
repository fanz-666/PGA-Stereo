#undef H_SWISH_KERN

// vim: syntax=cpp.doxygen
