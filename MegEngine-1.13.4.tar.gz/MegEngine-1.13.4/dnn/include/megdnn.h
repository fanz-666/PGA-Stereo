#pragma once

#include "megdnn/oprs.h"
#include "megdnn/version.h"

// vim: syntax=cpp.doxygen
