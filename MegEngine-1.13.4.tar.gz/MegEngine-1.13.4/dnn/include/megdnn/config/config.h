#include "megbrain_build_config.h"

#if !defined(__CUDACC__) && !defined(__HIPCC__)

#endif  // !defined(__CUDACC__)

// vim: syntax=cpp.doxygen
