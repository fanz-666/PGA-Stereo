#if MEGDNN_SHARED_LIB
#pragma GCC visibility pop
#endif

#ifdef MEGDNN_VISIBILITY_PROLOGUE_INCLUDED
#undef MEGDNN_VISIBILITY_PROLOGUE_INCLUDED
#else
#error "visibility_epilogue.h must be included after visibility_prologue.h"
#endif

// vim: syntax=cpp.doxygen
