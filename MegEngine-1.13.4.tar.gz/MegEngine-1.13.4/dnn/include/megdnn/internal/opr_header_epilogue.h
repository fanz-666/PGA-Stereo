// intentional no header guard here

#undef DEF_OPR_PARAM
#undef DEF_OPR_IMPL
#undef DEF_OPR_IMPL_CTOR

#include "./visibility_epilogue.h"

// vim: syntax=cpp.doxygen
