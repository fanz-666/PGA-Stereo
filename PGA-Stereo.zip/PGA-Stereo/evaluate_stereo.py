import sys
sys.path.append('core')

import os
# os.environ['CUDA_VISIBLE_DEVICES'] = '0,1'
import logging
import argparse
import time
import logging
import numpy as np
import torch
from tqdm import tqdm
from igev_stereo import IGEVStereo, autocast
import stereo_datasets as datasets
from utils.utils import InputPadder
from PIL import Image
import torch.utils.data as data
from pathlib import Path
from matplotlib import pyplot as plt
import torch.nn.functional as F

def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

@torch.no_grad()
def validate_eth3d(model, iters=32, mixed_prec=False):
    """ Peform validation using the ETH3D (train) split """
    model.eval()
    aug_params = {}
    val_dataset = datasets.ETH3D(aug_params)

    out_list, epe_list = [], []
    for val_id in range(len(val_dataset)):
        (imageL_file, imageR_file, GT_file), image1, image2, flow_gt, valid_gt = val_dataset[val_id]
        image1 = image1[None].cuda()
        image2 = image2[None].cuda()

        padder = InputPadder(image1.shape, divis_by=32)
        image1, image2 = padder.pad(image1, image2)

        with autocast(enabled=mixed_prec):
            flow_pr = model(image1, image2, iters=iters, test_mode=True)
        flow_pr = padder.unpad(flow_pr.float()).cpu().squeeze(0)
        assert flow_pr.shape == flow_gt.shape, (flow_pr.shape, flow_gt.shape)
        epe = torch.sum((flow_pr - flow_gt)**2, dim=0).sqrt()

        epe_flattened = epe.flatten()

        occ_mask = Image.open(GT_file.replace('disp0GT.pfm', 'mask0nocc.png'))

        occ_mask = np.ascontiguousarray(occ_mask).flatten()

        val = (valid_gt.flatten() >= 0.5) & (occ_mask == 255)
        # val = (valid_gt.flatten() >= 0.5)
        out = (epe_flattened > 1.0)
        image_out = out[val].float().mean().item()
        image_epe = epe_flattened[val].mean().item()
        logging.info(f"ETH3D {val_id+1} out of {len(val_dataset)}. EPE {round(image_epe,4)} D1 {round(image_out,4)}")
        epe_list.append(image_epe)
        out_list.append(image_out)

    epe_list = np.array(epe_list)
    out_list = np.array(out_list)

    epe = np.mean(epe_list)
    d1 = 100 * np.mean(out_list)

    print("Validation ETH3D: EPE %f, D1 %f" % (epe, d1))
    return {'eth3d-epe': epe, 'eth3d-d1': d1}


@torch.no_grad()
def validate_booster(model, iters=32, root="", mixed_prec=False):
    """ Peform validation using the Booster (TRAIN balanced) split """
    model.eval()
    aug_params = {}
    val_dataset = datasets.Booster(aug_params)

    epe_list = []
    bad1_list, bad2_list, bad3_list, bad5_list = [], [], [], []
    epe_trans_list, epe_notrans_list = [], []
    bad1_trans_list, bad2_trans_list, bad3_trans_list, bad5_trans_list = [], [], [], []
    bad1_notrans_list, bad2_notrans_list, bad3_notrans_list, bad5_notrans_list = [], [], [], []
    # epe_trans_b_list = []

    trans_b_bad1, trans_b_bad2, trans_b_bad3, trans_b_bad5, trans_b_sum = 0, 0, 0, 0, 0
    trans_f_bad1, trans_f_bad2, trans_f_bad3, trans_f_bad5, trans_f_sum = 0, 0, 0, 0, 0
    notrans_bad1, notrans_bad2, notrans_bad3, notrans_bad5, notrans_sum = 0, 0, 0, 0, 0

    for val_id in range(len(val_dataset)):
        (imageL_file, _, _), image1, image2, flow_gt, valid_gt = val_dataset[val_id]
        image1 = image1[None].cuda()
        image2 = image2[None].cuda()

        scale = 0.25
        image1 = F.interpolate(image1, scale_factor=(scale, scale), mode='bilinear', align_corners=True)
        image2 = F.interpolate(image2, scale_factor=(scale, scale), mode='bilinear', align_corners=True)
        flow_gt = F.interpolate(flow_gt.unsqueeze(0), scale_factor=(scale, scale), mode='bilinear',
                                align_corners=True).squeeze(0)
        flow_gt *= scale
        trans_mask = (valid_gt == 3).float()  # get transparent surfaces
        trans_mask = F.interpolate(trans_mask.unsqueeze(0).unsqueeze(0), scale_factor=(scale, scale), mode='bilinear',
                                   align_corners=True).squeeze(0).squeeze(0)

        padder = InputPadder(image1.shape, divis_by=32)
        image1, image2 = padder.pad(image1, image2)

        with autocast(enabled=mixed_prec):
             flow_pr = model(image1, image2, iters=iters, test_mode=True)
        flow_pr = padder.unpad(flow_pr).cpu().squeeze(0)

        assert flow_pr.shape == flow_gt.shape, (flow_pr.shape, flow_gt.shape)
        epe_full = torch.sum((flow_pr - flow_gt) ** 2, dim=0).sqrt()

        epe_full = epe_full.flatten()
        trans_mask = (trans_mask > 0).flatten()  # get transparent surfaces
        val = (flow_gt.abs() > 1).flatten()

        out1 = (epe_full > 1.0)
        out2 = (epe_full > 2.0)
        out3 = (epe_full > 3.0)
        out5 = (epe_full > 5.0)

        image_epe = epe_full[val].mean().item()
        image_bad1 = out1[val].float().mean().item()
        image_bad2 = out2[val].float().mean().item()
        image_bad3 = out3[val].float().mean().item()
        image_bad5 = out5[val].float().mean().item()
        epe_list.append(image_epe)
        bad1_list.append(image_bad1)
        bad2_list.append(image_bad2)
        bad3_list.append(image_bad3)
        bad5_list.append(image_bad5)

        logging.info(f"Booster Iter {val_id + 1} out of {len(val_dataset)}. " + \
                    f"EPE {round(image_epe, 4)} bad1 {round(image_bad1, 4)} " + \
                    f"bad2 {round(image_bad2, 4)} bad3 {round(image_bad3, 4)} " + \
                    f"bad5 {round(image_bad5, 4)} " + \
                    f"\r\n{imageL_file}")

        if (val & trans_mask).sum() > 0:
            image_epe_trans = epe_full[val & trans_mask].mean().item()
            image_bad1_trans = out1[val & trans_mask].float().mean().item()
            image_bad2_trans = out2[val & trans_mask].float().mean().item()
            image_bad3_trans = out3[val & trans_mask].float().mean().item()
            image_bad5_trans = out5[val & trans_mask].float().mean().item()
            epe_trans_list.append(image_epe_trans)
            bad1_trans_list.append(image_bad1_trans)
            bad2_trans_list.append(image_bad2_trans)
            bad3_trans_list.append(image_bad3_trans)
            bad5_trans_list.append(image_bad5_trans)

        if (val & ~trans_mask).sum() > 0:
            image_epe_notrans = epe_full[val & ~trans_mask].mean().item()
            image_bad1_notrans = out1[val & ~trans_mask].float().mean().item()
            image_bad2_notrans = out2[val & ~trans_mask].float().mean().item()
            image_bad3_notrans = out3[val & ~trans_mask].float().mean().item()
            image_bad5_notrans = out5[val & ~trans_mask].float().mean().item()
            epe_notrans_list.append(image_epe_notrans)
            bad1_notrans_list.append(image_bad1_notrans)
            bad2_notrans_list.append(image_bad2_notrans)
            bad3_notrans_list.append(image_bad3_notrans)
            bad5_notrans_list.append(image_bad5_notrans)

    epe = np.mean(np.array(epe_list))
    bad1 = 100 * np.mean(np.array(bad1_list))
    bad2 = 100 * np.mean(np.array(bad2_list))
    bad3 = 100 * np.mean(np.array(bad3_list))
    bad5 = 100 * np.mean(np.array(bad5_list))

    epe_trans = np.mean(np.array(epe_trans_list))
    bad1_trans = 100 * np.mean(np.array(bad1_trans_list))
    bad2_trans = 100 * np.mean(np.array(bad2_trans_list))
    bad3_trans = 100 * np.mean(np.array(bad3_trans_list))
    bad5_trans = 100 * np.mean(np.array(bad5_trans_list))

    epe_notrans = np.mean(np.array(epe_notrans_list))
    bad1_notrans = 100 * np.mean(np.array(bad1_notrans_list))
    bad2_notrans = 100 * np.mean(np.array(bad2_notrans_list))
    bad3_notrans = 100 * np.mean(np.array(bad3_notrans_list))
    bad5_notrans = 100 * np.mean(np.array(bad5_notrans_list))

    logging.info("Validation full: %f, %f, %f, %f, %f" % (epe, bad1, bad2, bad3, bad5))
    logging.info(
        "Validation Trans foreground: %f, %f, %f, %f, %f" % (epe_trans, bad1_trans, bad2_trans, bad3_trans, bad5_trans))
    logging.info("Validation non trans: %f, %f, %f, %f, %f" % (
    epe_notrans, bad1_notrans, bad2_notrans, bad3_notrans, bad5_notrans))
    # return {'booster-epe': epe, 'booster-epe_trans':epe_trans, 'booster-epe_notrans':epe_notrans}
    return {'booster-epe': epe, 'booster-bad1': bad1, 'booster-bad2': bad2, 'booster-bad3': bad3, 'booster-bad5': bad5,
            'booster-epe_trans': epe_trans, 'booster-bad1_trans': bad1_trans, 'booster-bad2_trans': bad2_trans,
            'booster-bad3_trans': bad3_trans, 'booster-bad5_trans': bad5_trans,
            'booster-epe_notrans': epe_notrans, 'booster-bad1_notrans': bad1_notrans,
            'booster-bad2_notrans': bad2_notrans, 'booster-bad3_notrans': bad3_notrans,
            'booster-bad5_notrans': bad5_notrans, }



# @torch.no_grad()
# def validate_booster(model, iters=32, mixed_prec=False):
#     """ Peform validation using the Booster (TRAIN balanced) split """
#     model.eval()
#     aug_params = {}
#     val_dataset = datasets.Booster(aug_params)
#
#     epe_list = []
#     bad1_list, bad2_list, bad3_list, bad5_list = [], [], [], []
#     epe_trans_list, epe_notrans_list = [], []
#     bad1_trans_list, bad2_trans_list, bad3_trans_list, bad5_trans_list = [], [], [], []
#     bad1_notrans_list, bad2_notrans_list, bad3_notrans_list, bad5_notrans_list = [], [], [], []
#     # epe_trans_b_list = []
#
#     trans_b_bad1, trans_b_bad2, trans_b_bad3, trans_b_bad5, trans_b_sum = 0, 0, 0, 0, 0
#     trans_f_bad1, trans_f_bad2, trans_f_bad3, trans_f_bad5, trans_f_sum = 0, 0, 0, 0, 0
#     notrans_bad1, notrans_bad2, notrans_bad3, notrans_bad5, notrans_sum = 0, 0, 0, 0, 0
#
#     for val_id in range(len(val_dataset)):
#         (imageL_file, _, _), image1, image2, flow_gt, valid_gt, intrinsic = val_dataset[val_id]
#         image1 = image1[None].cuda()
#         image2 = image2[None].cuda()
#
#         scale = 0.25
#         image1 = F.interpolate(image1, scale_factor=(scale, scale), mode='bilinear', align_corners=True)
#         image2 = F.interpolate(image2, scale_factor=(scale, scale), mode='bilinear', align_corners=True)
#         flow_gt = F.interpolate(flow_gt.unsqueeze(0), scale_factor=(scale, scale), mode='bilinear',
#                                 align_corners=True).squeeze(0)
#         flow_gt *= scale
#         trans_mask = (valid_gt == 3).float()  # get transparent surfaces
#         trans_mask = F.interpolate(trans_mask.unsqueeze(0).unsqueeze(0), scale_factor=(scale, scale), mode='bilinear',
#                                    align_corners=True).squeeze(0).squeeze(0)
#
#         padder = InputPadder(image1.shape, divis_by=32)
#         image1, image2 = padder.pad(image1, image2)
#
#         with autocast(enabled=mixed_prec):
#             _, flow_pr = model(image1, image2, iters=iters, test_mode=True)
#         flow_pr = padder.unpad(flow_pr).cpu().squeeze(0)
#
#         assert flow_pr.shape == flow_gt.shape, (flow_pr.shape, flow_gt.shape)
#         epe_full = torch.sum((flow_pr - flow_gt) ** 2, dim=0).sqrt()
#
#         epe_full = epe_full.flatten()
#         trans_mask = (trans_mask > 0).flatten()  # get transparent surfaces
#         val = (flow_gt.abs() > 1).flatten()
#
#         out1 = (epe_full > 1.0)
#         out2 = (epe_full > 2.0)
#         out3 = (epe_full > 3.0)
#         out5 = (epe_full > 5.0)
#
#         image_epe = epe_full[val].mean().item()
#         image_bad1 = out1[val].float().mean().item()
#         image_bad2 = out2[val].float().mean().item()
#         image_bad3 = out3[val].float().mean().item()
#         image_bad5 = out5[val].float().mean().item()
#         epe_list.append(image_epe)
#         bad1_list.append(image_bad1)
#         bad2_list.append(image_bad2)
#         bad3_list.append(image_bad3)
#         bad5_list.append(image_bad5)
#
#         logging.info(f"Booster Iter {val_id + 1} out of {len(val_dataset)}. " + \
#                     f"EPE {round(image_epe, 4)} bad1 {round(image_bad1, 4)} " + \
#                     f"bad2 {round(image_bad2, 4)} bad3 {round(image_bad3, 4)} " + \
#                     f"bad5 {round(image_bad5, 4)} " + \
#                     f"\r\n{imageL_file}")
#
#         if (val & trans_mask).sum() > 0:
#             image_epe_trans = epe_full[val & trans_mask].mean().item()
#             image_bad1_trans = out1[val & trans_mask].float().mean().item()
#             image_bad2_trans = out2[val & trans_mask].float().mean().item()
#             image_bad3_trans = out3[val & trans_mask].float().mean().item()
#             image_bad5_trans = out5[val & trans_mask].float().mean().item()
#             epe_trans_list.append(image_epe_trans)
#             bad1_trans_list.append(image_bad1_trans)
#             bad2_trans_list.append(image_bad2_trans)
#             bad3_trans_list.append(image_bad3_trans)
#             bad5_trans_list.append(image_bad5_trans)
#
#         if (val & ~trans_mask).sum() > 0:
#             image_epe_notrans = epe_full[val & ~trans_mask].mean().item()
#             image_bad1_notrans = out1[val & ~trans_mask].float().mean().item()
#             image_bad2_notrans = out2[val & ~trans_mask].float().mean().item()
#             image_bad3_notrans = out3[val & ~trans_mask].float().mean().item()
#             image_bad5_notrans = out5[val & ~trans_mask].float().mean().item()
#             epe_notrans_list.append(image_epe_notrans)
#             bad1_notrans_list.append(image_bad1_notrans)
#             bad2_notrans_list.append(image_bad2_notrans)
#             bad3_notrans_list.append(image_bad3_notrans)
#             bad5_notrans_list.append(image_bad5_notrans)
#
#     epe = np.mean(np.array(epe_list))
#     bad1 = 100 * np.mean(np.array(bad1_list))
#     bad2 = 100 * np.mean(np.array(bad2_list))
#     bad3 = 100 * np.mean(np.array(bad3_list))
#     bad5 = 100 * np.mean(np.array(bad5_list))
#
#     epe_trans = np.mean(np.array(epe_trans_list))
#     bad1_trans = 100 * np.mean(np.array(bad1_trans_list))
#     bad2_trans = 100 * np.mean(np.array(bad2_trans_list))
#     bad3_trans = 100 * np.mean(np.array(bad3_trans_list))
#     bad5_trans = 100 * np.mean(np.array(bad5_trans_list))
#
#     epe_notrans = np.mean(np.array(epe_notrans_list))
#     bad1_notrans = 100 * np.mean(np.array(bad1_notrans_list))
#     bad2_notrans = 100 * np.mean(np.array(bad2_notrans_list))
#     bad3_notrans = 100 * np.mean(np.array(bad3_notrans_list))
#     bad5_notrans = 100 * np.mean(np.array(bad5_notrans_list))
#
#     logging.info("Validation full: %f, %f, %f, %f, %f" % (epe, bad1, bad2, bad3, bad5))
#     logging.info(
#         "Validation Trans foreground: %f, %f, %f, %f, %f" % (epe_trans, bad1_trans, bad2_trans, bad3_trans, bad5_trans))
#     logging.info("Validation non trans: %f, %f, %f, %f, %f" % (
#     epe_notrans, bad1_notrans, bad2_notrans, bad3_notrans, bad5_notrans))
#     # return {'booster-epe': epe, 'booster-epe_trans':epe_trans, 'booster-epe_notrans':epe_notrans}
#     return {'booster-epe': epe, 'booster-bad1': bad1, 'booster-bad2': bad2, 'booster-bad3': bad3, 'booster-bad5': bad5,
#             'booster-epe_trans': epe_trans, 'booster-bad1_trans': bad1_trans, 'booster-bad2_trans': bad2_trans,
#             'booster-bad3_trans': bad3_trans, 'booster-bad5_trans': bad5_trans,
#             'booster-epe_notrans': epe_notrans, 'booster-bad1_notrans': bad1_notrans,
#             'booster-bad2_notrans': bad2_notrans, 'booster-bad3_notrans': bad3_notrans,
#             'booster-bad5_notrans': bad5_notrans, }
@torch.no_grad()
def validate_vkitti2(model, iters=32, mixed_prec=False):
    """ Peform validation using the vkitti (train) split """
    model.eval()
    aug_params = {}
    val_dataset = datasets.VKITTI2(aug_params)
    torch.backends.cudnn.benchmark = True

    out_list, epe_list, elapsed_list = [], [], []
    for val_id in range(len(val_dataset)):
        _, image1, image2, flow_gt, valid_gt = val_dataset[val_id]
        image1 = image1[None].cuda()
        image2 = image2[None].cuda()

        padder = InputPadder(image1.shape, divis_by=32)
        image1, image2 = padder.pad(image1, image2)

        with autocast(enabled=mixed_prec):
            start = time.time()
            flow_pr = model(image1, image2, iters=iters, test_mode=True)
            end = time.time()

        if val_id > 50:
            elapsed_list.append(end - start)
        flow_pr = padder.unpad(flow_pr).cpu().squeeze(0)

        assert flow_pr.shape == flow_gt.shape, (flow_pr.shape, flow_gt.shape)
        epe = torch.sum((flow_pr - flow_gt) ** 2, dim=0).sqrt()

        epe_flattened = epe.flatten()
        val = (valid_gt.flatten() >= 0.5) & (flow_gt.abs().flatten() < 192)
        # val = valid_gt.flatten() >= 0.5

        out = (epe_flattened > 3.0)
        image_out = out[val].float().mean().item()
        image_epe = epe_flattened[val].mean().item()
        if val_id < 9 or (val_id + 1) % 10 == 0:
            logging.info(
                f"VKITTI Iter {val_id + 1} out of {len(val_dataset)}. EPE {round(image_epe, 4)} D1 {round(image_out, 4)}. Runtime: {format(end - start, '.3f')}s ({format(1 / (end - start), '.2f')}-FPS)")
        epe_list.append(epe_flattened[val].mean().item())
        out_list.append(out[val].cpu().numpy())

        # if val_id > 20:
        #     break

    epe_list = np.array(epe_list)
    out_list = np.concatenate(out_list)

    epe = np.mean(epe_list)
    d1 = 100 * np.mean(out_list)

    avg_runtime = np.mean(elapsed_list)

    print(f"Validation VKITTI: EPE {epe}, D1 {d1}, {format(1 / avg_runtime, '.2f')}-FPS ({format(avg_runtime, '.3f')}s)")
    return {'vkitti-epe': epe, 'vkitti-d1': d1}

@torch.no_grad()
def validate_drivingstereo(model, iters=32, mixed_prec=False):
    """ Peform validation using the KITTI-2015 (train) split """
    model.eval()
    aug_params = {}
    val_dataset = datasets.DrivingStereo(aug_params)
    torch.backends.cudnn.benchmark = True

    out_list, epe_list, elapsed_list = [], [], []
    for val_id in range(len(val_dataset)):
        _, image1, image2, flow_gt, valid_gt = val_dataset[val_id]
        image1 = image1[None].cuda()
        image2 = image2[None].cuda()

        padder = InputPadder(image1.shape, divis_by=32)
        image1, image2 = padder.pad(image1, image2)

        with autocast(enabled=mixed_prec):
            start = time.time()
            flow_pr = model(image1, image2, iters=iters, test_mode=True)
            end = time.time()

        if val_id > 50:
            elapsed_list.append(end-start)
        flow_pr = padder.unpad(flow_pr).cpu().squeeze(0)

        assert flow_pr.shape == flow_gt.shape, (flow_pr.shape, flow_gt.shape)
        epe = torch.sum((flow_pr - flow_gt)**2, dim=0).sqrt()

        epe_flattened = epe.flatten()
        val = (valid_gt.flatten() >= 0.5) & (flow_gt.abs().flatten() < 192)
        # val = valid_gt.flatten() >= 0.5

        out = (epe_flattened > 3.0)
        image_out = out[val].float().mean().item()
        image_epe = epe_flattened[val].mean().item()
        if val_id < 9 or (val_id+1)%10 == 0:
            logging.info(f"KITTI Iter {val_id+1} out of {len(val_dataset)}. EPE {round(image_epe,4)} D1 {round(image_out,4)}. Runtime: {format(end-start, '.3f')}s ({format(1/(end-start), '.2f')}-FPS)")
        epe_list.append(epe_flattened[val].mean().item())
        out_list.append(out[val].cpu().numpy())

    epe_list = np.array(epe_list)
    out_list = np.concatenate(out_list)

    epe = np.mean(epe_list)
    d1 = 100 * np.mean(out_list)

    avg_runtime = np.mean(elapsed_list)

    print(f"Validation drivingstereo: EPE {epe}, D1 {d1}, {format(1/avg_runtime, '.2f')}-FPS ({format(avg_runtime, '.3f')}s)")
    return {'drivingstereo-epe': epe, 'drivingstereo-d1': d1, 'FPS': format(1/avg_runtime, '.2f'), 'S': format(avg_runtime, '.3f')}

# @torch.no_grad()
# def validate_sceneflow(model, iters=32, mixed_prec=False):
#     """ Peform validation using the Scene Flow (TEST) split """
#     model.eval()
#     val_dataset = datasets.SceneFlowDatasets(dstype='frames_finalpass', things_test=True)
#     val_loader = data.DataLoader(val_dataset, batch_size=4,
#         pin_memory=True, shuffle=False, num_workers=8)
#
#     out_list, epe_list = [], []
#     for i_batch, (_, *data_blob) in enumerate(tqdm(val_loader)):
#         image1, image2, disp_gt, valid_gt = [x for x in data_blob]
#
#         image1 = image1.cuda()
#         image2 = image2.cuda()
#
#         padder = InputPadder(image1.shape, divis_by=32)
#         image1, image2 = padder.pad(image1, image2)
#
#         with autocast(enabled=mixed_prec):
#             disp_pr = model(image1, image2, iters=iters, test_mode=True)
#         disp_pr = padder.unpad(disp_pr).cpu()
#         assert disp_pr.shape == disp_gt.shape, (disp_pr.shape, disp_gt.shape)
#         epe = torch.abs(disp_pr - disp_gt)
#
#         epe = epe.flatten()
#         val = (disp_gt.abs().flatten() < 768)
#         if(np.isnan(epe[val].mean().item())):
#             continue
#
#         out = (epe > 3.0)
#         epe_list.append(epe[val].mean().item())
#         out_list.append(out[val].cpu().numpy())
#
#     epe_list = np.array(epe_list)
#     out_list = np.concatenate(out_list)
#
#     epe = np.mean(epe_list)
#     d1 = 100 * np.mean(out_list)
#
#     f = open('test_sceneflow.txt', 'a')
#     f.write("Validation Scene Flow: %f, %f\n" % (epe, d1))
#
#     print("Validation Scene Flow: %f, %f" % (epe, d1))
#     return {'scene-disp-epe': epe, 'scene-disp-d1': d1}

@torch.no_grad()
def validate_sceneflow(model, iters=32, mixed_prec=False):
    """ Peform validation using the Scene Flow (TEST) split """
    model.eval()
    val_dataset = datasets.SceneFlowDatasets(dstype='frames_finalpass', things_test=True)
    torch.backends.cudnn.benchmark = True

    out_list, epe_list, elapsed_list = [], [], []
    for val_id in tqdm(range(len(val_dataset))):
        _, image1, image2, flow_gt, valid_gt = val_dataset[val_id]

        image1 = image1[None].cuda()
        image2 = image2[None].cuda()

        padder = InputPadder(image1.shape, divis_by=32)
        image1, image2 = padder.pad(image1, image2)

        with autocast(enabled=mixed_prec):
            start = time.time()
            flow_pr = model(image1, image2, iters=iters, test_mode=True)
            end = time.time()
        # print(torch.cuda.memory_summary(device=None, abbreviated=False))
        if val_id > 50:
            elapsed_list.append(end-start)

        flow_pr = padder.unpad(flow_pr).cpu().squeeze(0)
        assert flow_pr.shape == flow_gt.shape, (flow_pr.shape, flow_gt.shape)

        # epe = torch.sum((flow_pr - flow_gt)**2, dim=0).sqrt()
        epe = torch.abs(flow_pr - flow_gt)

        epe = epe.flatten()
        val = (valid_gt.flatten() >= 0.5) & (flow_gt.abs().flatten() < 198)

        if(np.isnan(epe[val].mean().item())):
            continue

        out = (epe > 1.0)
        image_out = out[val].float().mean().item()
        image_epe = epe[val].mean().item()
        if val_id < 9 or (val_id + 1) % 10 == 0:
            logging.info(
                f"Scene Flow Iter {val_id + 1} out of {len(val_dataset)}. EPE {round(image_epe, 4)} D1 {round(image_out, 4)}. Runtime: {format(end - start, '.3f')}s ({format(1 / (end - start), '.2f')}-FPS)")

        print('epe', epe[val].mean().item())
        epe_list.append(epe[val].mean().item())
        out_list.append(out[val].cpu().numpy())

    epe_list = np.array(epe_list)
    out_list = np.concatenate(out_list)

    epe = np.mean(epe_list)
    d1 = 100 * np.mean(out_list)

    avg_runtime = np.mean(elapsed_list)
    # f = open('test.txt', 'a')
    # f.write("Validation Scene Flow: %f, %f\n" % (epe, d1))

    print(f"Validation Scene Flow: EPE {epe}, D1 {d1}, {format(1/avg_runtime, '.2f')}-FPS ({format(avg_runtime, '.3f')}s)" )
    return {'scene-disp-epe': epe, 'scene-disp-d1': d1, 'FPS': format(1/avg_runtime, '.2f'), 'S': format(avg_runtime, '.3f')}


@torch.no_grad()
def validate_middlebury(model, iters=32, split='MiddEval3', resolution='F', mixed_prec=False):
    """ Peform validation using the Middlebury-V3 dataset """
    model.eval()
    aug_params = {}
    val_dataset = datasets.Middlebury(aug_params, split=split, resolution=resolution)
    out_list, epe_list = [], []

    for val_id in range(len(val_dataset)):
        (imageL_file, _, _), image1, image2, flow_gt, valid_gt = val_dataset[val_id]
        image1 = image1[None].cuda()
        image2 = image2[None].cuda()
        padder = InputPadder(image1.shape, divis_by=32)
        image1, image2 = padder.pad(image1, image2)

        with autocast(enabled=mixed_prec):
            flow_pr = model(image1, image2, iters=iters, test_mode=True)
        flow_pr = padder.unpad(flow_pr).cpu().squeeze(0)
        assert flow_pr.shape == flow_gt.shape, (flow_pr.shape, flow_gt.shape)
        epe = torch.sum((flow_pr - flow_gt)**2, dim=0).sqrt()
        epe_flattened = epe.flatten()

        occ_mask = Image.open(imageL_file.replace('im0.png', 'mask0nocc.png')).convert('L')
        occ_mask = np.ascontiguousarray(occ_mask, dtype=np.float32).flatten()
        val = (valid_gt.reshape(-1) >= 0.5) & (occ_mask==255)
        out = (epe_flattened > 2.0)
        image_out = out[val].float().mean().item()
        image_epe = epe_flattened[val].mean().item()
        logging.info(f"Middlebury Iter {val_id+1} out of {len(val_dataset)}. EPE {round(image_epe,4)} D1 {round(image_out,4)}")
        epe_list.append(image_epe)
        out_list.append(image_out)

    epe_list = np.array(epe_list)
    out_list = np.array(out_list)

    epe = np.mean(epe_list)
    d1 = 100 * np.mean(out_list)

    f = open('test_middlebury.txt', 'a')
    f.write("Validation Middlebury: %f, %f\n" % (epe, d1))

    print(f"Validation Middlebury{split}: EPE {epe}, D1 {d1}")
    return {f'middlebury{split}-epe': epe, f'middlebury{split}-d1': d1}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--restore_ckpt', help="restore checkpoint", default='D:\ZF\ZF1\sceneflow.pth')
    parser.add_argument('--dataset', help="dataset for evaluation", default='booster', choices=["eth3d", "kitti", "vkitti2", "booster", "sceneflow", "drivingstereo"] + [f"middlebury_{s}" for s in 'FHQ'])
    parser.add_argument('--mixed_precision', default=False, action='store_true', help='use mixed precision')
    parser.add_argument('--precision_dtype', default='float32', choices=['float16', 'bfloat16', 'float32'], help='Choose precision type: float16 or bfloat16 or float32')
    parser.add_argument('--valid_iters', type=int, default=16, help='number of flow-field updates during forward pass')
    parser.add_argument('--encoder', type=str, default='vitl', choices=['vits', 'vitb', 'vitl', 'vitg'])
    # Architecure choices
    parser.add_argument('--hidden_dims', nargs='+', type=int, default=[128]*3, help="hidden state and context dimensions")
    parser.add_argument('--corr_levels', type=int, default=2, help="number of levels in the correlation pyramid")
    parser.add_argument('--corr_radius', type=int, default=4, help="width of the correlation pyramid")
    parser.add_argument('--n_downsample', type=int, default=2, help="resolution of the disparity field (1/2^K)")
    parser.add_argument('--n_gru_layers', type=int, default=3, help="number of hidden GRU levels")
    parser.add_argument('--max_disp', type=int, default=192, help="max disp range")
    # parser.add_argument('--s_disp_range', type=int, default=48, help="max disp of small disparity-range geometry encoding volume")
    # parser.add_argument('--m_disp_range', type=int, default=96, help="max disp of medium disparity-range geometry encoding volume")
    # parser.add_argument('--l_disp_range', type=int, default=192, help="max disp of large disparity-range geometry encoding volume")
    # parser.add_argument('--s_disp_interval', type=int, default=1, help="disp interval of small disparity-range geometry encoding volume")
    # parser.add_argument('--m_disp_interval', type=int, default=2, help="disp interval of medium disparity-range geometry encoding volume")
    # parser.add_argument('--l_disp_interval', type=int, default=4, help="disp interval of large disparity-range geometry encoding volume")
    args = parser.parse_args()

    model = torch.nn.DataParallel(IGEVStereo(args), device_ids=[0])
    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s %(levelname)-8s [%(filename)s:%(lineno)d] %(message)s')

    if args.restore_ckpt is not None:
        assert args.restore_ckpt.endswith(".pth")
        logging.info("Loading checkpoint...")
        checkpoint = torch.load(args.restore_ckpt)
        model.load_state_dict(checkpoint, strict=True)
        logging.info(f"Done loading checkpoint")

    model.cuda()
    model.eval()

    print(f"The model has {format(count_parameters(model)/1e6, '.2f')}M learnable parameters.")

    if args.dataset == 'eth3d':
        validate_eth3d(model, iters=args.valid_iters, mixed_prec=args.mixed_precision)

    elif args.dataset == 'booster':
        validate_booster(model, iters=args.valid_iters, mixed_prec=args.mixed_precision)

    elif args.dataset == 'drivingstereo':
        validate_drivingstereo(model, iters=args.valid_iters, mixed_prec=args.mixed_precision)

    elif args.dataset == 'vkitti2':
        validate_vkitti2(model, iters=args.valid_iters, mixed_prec=args.mixed_precision)

    elif args.dataset in [f"middlebury_{s}" for s in 'FHQ']:
        validate_middlebury(model, iters=args.valid_iters, resolution=args.dataset[-1], mixed_prec=args.mixed_precision)

    elif args.dataset == 'sceneflow':
        validate_sceneflow(model, iters=args.valid_iters, mixed_prec=args.mixed_precision)
