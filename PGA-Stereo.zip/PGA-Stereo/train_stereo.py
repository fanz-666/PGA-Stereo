import os
os.environ['CUDA_VISIBLE_DEVICES'] = '0,1'
os.environ['PYTORCH_CUDA_ALLOC_CONF'] = 'expandable_segments:True'
import argparse
import logging
import numpy as np
from pathlib import Path
from tqdm import tqdm

from torch.utils.tensorboard import SummaryWriter
import torch
import torch.nn as nn
import torch.optim as optim
from core.igev_stereo import IGEVStereo
from evaluate_stereo import *
import core.stereo_datasets as datasets
import torch.nn.functional as F
import csv
from datetime import datetime

try:
    from torch.cuda.amp import GradScaler
except:
    class GradScaler:
        def __init__(self):
            pass
        def scale(self, loss):
            return loss
        def unscale_(self, optimizer):
            pass
        def step(self, optimizer):
            optimizer.step()
        def update(self):
            pass

# --------------------- 新增日志保存函数（不修改Logger类）---------------------
def save_train_log(logdir: str, step: int, loss: float, metrics: dict, lr: float):
        """保存训练日志到txt文件"""
        log_path = Path(logdir) / "training_log.txt"
        with open(log_path, 'a') as f:
            f.write(
                f"Step: {step}\n"
                f"  Loss: {loss:.6f}\n"
                f"  EPE: {metrics['epe']:.4f}\n"
                f"  1px: {metrics['1px']:.2%}\n"
                f"  3px: {metrics['3px']:.2%}\n"
                f"  5px: {metrics['5px']:.2%}\n"
                f"  LR: {lr:.6e}\n"
                f"{'-' * 60}\n"
            )
def save_val_log(logdir: str, step: int, dataset: str, metrics: dict):
        """保存验证日志到带数据集名称的txt文件"""
        log_dir = Path(logdir) / "validation_logs"
        log_dir.mkdir(exist_ok=True)

        log_path = log_dir / f"step_{step:06d}_{dataset}.txt"
        with open(log_path, 'w') as f:
            f.write(f"Validation Report - Step {step} ({dataset.upper()})\n")
            f.write("=" * 50 + "\n")
            f.write(f"{'Metric':<20} | {'Value':<15} | {'Unit':<10}\n")
            f.write("-" * 50 + "\n")
            for k, v in metrics.items():
                # 自动检测指标类型
                if 'epe' in k:
                    unit = 'pixels'
                    val = f"{v:.4f}"
                elif 'd1' in k:
                    unit = '%'
                    val = f"{v:.2f}"
                elif 'fps' in k:
                    unit = 'frames/s'
                    val = f"{v:.1f}"
                else:
                    unit = ''
                    val = str(v)

                f.write(f"{k:<20} | {val:<15} | {unit:<10}\n")
            f.write("=" * 50 + "\n\n")

def sequence_loss(args, agg_preds, iter_preds, disp_gt, valid, loss_gamma=0.9):
    """ Loss function defined over sequence of flow predictions """

    n_predictions = len(iter_preds)
    assert n_predictions >= 1
    if ('kitti' in args.train_datasets) or ('eth3d' in args.train_datasets):
        max_disp0 = 192
        max_disp1 = 192
        max_disp = 192
    else:
        max_disp0 = 192
        max_disp1 = 192
        max_disp = 192

    disp_loss = 0.0
    mag = torch.sum(disp_gt**2, dim=1).sqrt()
    mask0 = ((valid >= 0.5) & (mag < max_disp0)).unsqueeze(1)
    mask1 = ((valid >= 0.5) & (mag < max_disp1)).unsqueeze(1)
    mask = ((valid >= 0.5) & (mag < max_disp)).unsqueeze(1)
    assert mask.shape == disp_gt.shape, [mask.shape, disp_gt.shape]
    assert not torch.isinf(disp_gt[mask.bool()]).any()

    disp_loss += 1.0 * F.smooth_l1_loss(agg_preds[0][mask0.bool()], disp_gt[mask0.bool()], reduction='mean')
    disp_loss += 0.5 * F.smooth_l1_loss(agg_preds[1][mask1.bool()], disp_gt[mask1.bool()], reduction='mean')
    disp_loss += 0.2 * F.smooth_l1_loss(agg_preds[2][mask.bool()], disp_gt[mask.bool()], reduction='mean')

    for i in range(n_predictions):
        adjusted_loss_gamma = loss_gamma**(15/(n_predictions - 1))
        i_weight = adjusted_loss_gamma**(n_predictions - i - 1)
        i_loss = (iter_preds[i] - disp_gt).abs()
        assert i_loss.shape == mask.shape, [i_loss.shape, mask.shape, disp_gt.shape, iter_preds[i].shape]
        disp_loss += i_weight * i_loss[mask.bool()].mean()

    epe = torch.sum((iter_preds[-1] - disp_gt)**2, dim=1).sqrt()
    epe = epe.view(-1)[mask.view(-1)]

    metrics = {
        'epe': epe.mean().item(),
        '1px': (epe < 1).float().mean().item(),
        '3px': (epe < 3).float().mean().item(),
        '5px': (epe < 5).float().mean().item(),
    }

    return disp_loss, metrics


# def fetch_optimizer(args, model):
#     """ Create the optimizer and learning rate scheduler """
#     optimizer = optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.wdecay, eps=1e-8)
#
#     scheduler = optim.lr_scheduler.OneCycleLR(optimizer, args.lr, args.num_steps+100,
#             pct_start=0.01, cycle_momentum=False, anneal_strategy='linear')
#     return optimizer, scheduler

def fetch_optimizer(args, model):
    """ Create the optimizer and learning rate scheduler """
    DPT_params = list(map(id, model.module.feat_decoder.parameters()))
    rest_params = filter(lambda x:id(x) not in DPT_params and x.requires_grad, model.parameters())

    params_dict = [{'params': model.module.feat_decoder.parameters(), 'lr': args.lr/2.0},
                   {'params': rest_params, 'lr': args.lr}, ]
    optimizer = optim.AdamW(params_dict, lr=args.lr, weight_decay=args.wdecay, eps=1e-8)

    scheduler = optim.lr_scheduler.OneCycleLR(optimizer, [args.lr/2.0, args.lr], args.num_steps+100,
            pct_start=0.01, cycle_momentum=False, anneal_strategy='linear')


    return optimizer, scheduler

class Logger:
    SUM_FREQ = 100
    def __init__(self, model, scheduler, logdir):
        self.model = model
        self.scheduler = scheduler
        self.total_steps = 0
        self.running_loss = {}
        self.logdir = logdir
        self.writer = SummaryWriter(log_dir=self.logdir)



    def _print_training_status(self):
        metrics_data = [self.running_loss[k]/Logger.SUM_FREQ for k in sorted(self.running_loss.keys())]
        training_str = "[{:6d}, {:10.7f}] ".format(self.total_steps+1, self.scheduler.get_last_lr()[0])
        metrics_str = ("{:10.4f}, "*len(metrics_data)).format(*metrics_data)
        
        # print the training status
        logging.info(f"Training Metrics ({self.total_steps}): {training_str + metrics_str}")

        if self.writer is None:
            self.writer = SummaryWriter(log_dir=self.logdir)

        for k in self.running_loss:
            self.writer.add_scalar(k, self.running_loss[k]/Logger.SUM_FREQ, self.total_steps)
            self.running_loss[k] = 0.0


    def push(self, metrics):
        self.total_steps += 1

        for key in metrics:
            if key not in self.running_loss:
                self.running_loss[key] = 0.0

            self.running_loss[key] += metrics[key]

        if self.total_steps % Logger.SUM_FREQ == Logger.SUM_FREQ-1:
            self._print_training_status()
            self.running_loss = {}

    def write_dict(self, results):
        if self.writer is None:
            self.writer = SummaryWriter(log_dir=self.logdir)

        for key in results:
            self.writer.add_scalar(key, results[key], self.total_steps)

            # ✨新增：写入验证结果到CSV
        if 'scene-disp-epe' in results and 'scene-disp-d1' in results:
            val_data = {
                "step": self.total_steps,
                "scene-disp-epe": results['scene-disp-epe'],
                "scene-disp-d1": results['scene-disp-d1'],
                "runtime": results.get('runtime', 0)
            }
            with open(self.val_csv_path, 'a') as f:
                writer = csv.DictWriter(f, fieldnames=val_data.keys())
                writer.writerow(val_data)

    def close(self):
        self.writer.close()


def train(args):

    model = nn.DataParallel(IGEVStereo(args))
    print("Parameter Count: %d" % count_parameters(model))

    train_loader = datasets.fetch_dataloader(args)
    optimizer, scheduler = fetch_optimizer(args, model)
    total_steps = 0
    logger = Logger(model, scheduler, args.logdir)

        # # model.load_state_dict(torch.load(args.restore_ckpt), strict=True)
        # checkpoint = torch.load(args.restore_ckpt)
        # model.load_state_dict(checkpoint['model'])
        # optimizer.load_state_dict(checkpoint['optimizer'])
        # scheduler.load_state_dict(checkpoint['scheduler'])
        # total_steps = checkpoint['total_steps']
        # global_batch_num = checkpoint['global_batch_num']
        # print(f"从检查点 {args.restore_ckpt} 恢复，步数={total_steps}")
        # # 同步优化器学习率
        # for param_group, lr in zip(optimizer.param_groups, scheduler.get_last_lr()):
        #     param_group['lr'] = lr
        #
        # # 确保调度器步数正确
        # scheduler._step_count = total_steps
    if args.restore_ckpt is not None:
        assert args.restore_ckpt.endswith(".pth")
        logging.info("Loading checkpoint...")
        checkpoint = torch.load(args.restore_ckpt)
        model.load_state_dict(checkpoint, strict=True)
        # model.load_state_dict(checkpoint['model'])
        logging.info(f"Done loading checkpoint")

    model.cuda()
    model.train()
    model.module.freeze_bn() # We keep BatchNorm frozen

    validation_frequency = 500

    scaler = GradScaler(enabled=args.mixed_precision)

    should_keep_training = True
    global_batch_num = 0


    while should_keep_training:
        for i_batch, (_, *data_blob) in enumerate(tqdm(train_loader)):
            optimizer.zero_grad()
            image1, image2, disp_gt, valid = [x.cuda() for x in data_blob]

            assert model.training
            agg_preds, iter_preds = model(image1, image2, iters=args.train_iters)
            assert model.training

            loss, metrics = sequence_loss(args, agg_preds, iter_preds, disp_gt, valid)
            logger.writer.add_scalar("live_loss", loss.item(), global_batch_num)
            logger.writer.add_scalar(f'learning_rate', optimizer.param_groups[0]['lr'], global_batch_num)
            global_batch_num += 1
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)

            scaler.step(optimizer)
            scheduler.step()
            scaler.update()
            logger.push(metrics)

            # ✨新增训练日志保存（每SUM_FREQ步）
            if total_steps % Logger.SUM_FREQ == Logger.SUM_FREQ - 1:
                save_train_log(
                    args.logdir,
                    total_steps,
                    loss.item(),
                    metrics,
                    optimizer.param_groups[0]['lr']
                )

                # 修改保存点
            # if total_steps % validation_frequency == validation_frequency - 1:
            #     save_path = Path(args.logdir) / f"checkpoint_{total_steps}.pth"
            #     logging.info(f"Saving file {save_path.absolute()}")
            #     torch.save({
            #         'model': model.state_dict(),
            #         'optimizer': optimizer.state_dict(),
            #         'scheduler': scheduler.state_dict(),
            #         'total_steps': total_steps,
            #         'global_batch_num': global_batch_num,
            #         'cmd_args': vars(args)  # 保存当前参数配置
            #     }, save_path)
            if total_steps % validation_frequency == validation_frequency - 1:
                save_path = Path(args.logdir + '/%d_%s.pth' % (total_steps + 1, args.name))
                logging.info(f"Saving file {save_path.absolute()}")
                torch.save(model.state_dict(), save_path)
                if 'sceneflow' in args.train_datasets:
                    results = validate_sceneflow(model.module, iters=args.valid_iters)
                    dataset_tag = 'sceneflow'
                elif 'kitti' in args.train_datasets:
                    results = validate_kitti(model.module, iters=args.valid_iters)
                    dataset_tag = 'kitti'
                elif 'vkitti2' in args.train_datasets:
                    results = validate_vkitti2(model.module, iters=args.valid_iters)
                    dataset_tag = 'vkitti2'
                elif 'middlebury' in args.train_datasets:
                    results = validate_middlebury(model.module, iters=args.valid_iters)
                    dataset_tag = 'middlebury'
                elif 'eth3d' in args.train_datasets:
                    results = validate_eth3d(model.module, iters=args.valid_iters)
                    dataset_tag = 'eth3d'
                else:
                    print(f"Val dataset is not supported.")

                    # 保存验证日志
                save_val_log(
                    logdir=args.logdir,
                    step=total_steps,
                    dataset=dataset_tag,
                    metrics=results
                )
                # logger.write_dict(results)
                model.train()
                model.module.freeze_bn()

            total_steps += 1

            if total_steps > args.num_steps:
                should_keep_training = False
                break

    print("FINISHED TRAINING")
    logger.close()
    PATH = args.logdir + '/%s.pth' % args.name
    torch.save(model.state_dict(), PATH)

    return PATH


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--name', default='igev-stereo', help="name your experiment")
    parser.add_argument('--restore_ckpt', default='checkpoints/16000_igev-stereo.pth', help='load the weights from a specific checkpoint')
    parser.add_argument('--logdir', default='./checkpoints', help='the directory to save logs and checkpoints')
    parser.add_argument('--resume', action='store_true', help='continue training the model')
    parser.add_argument('--mixed_precision', default=True, action='store_true', help='use mixed precision')
    parser.add_argument('--precision_dtype', default='bfloat16', choices=['float16', 'bfloat16', 'float32'], help='Choose precision type: float16 or bfloat16 or float32')
    # parser.add_argument('mode', default="stereo", help='train stereo')
    # Training parameters
    parser.add_argument('--batch_size', type=int, default=8, help="batch size used during training.")
    parser.add_argument('--train_datasets', default='kitti', choices=['sceneflow', 'kitti', 'vkitti2', 'middlebury_train', 'middlebury_finetune', 'eth3d_train', 'eth3d_finetune'], help="training datasets.")
    parser.add_argument('--lr', type=float, default=0.00015, help="max learning rate.")
    parser.add_argument('--num_steps', type=int, default=60000, help="length of training schedule.")
    parser.add_argument('--image_size', type=int, nargs='+', default=[256, 320], help="size of the random image crops used during training.")
    parser.add_argument('--train_iters', type=int, default=22, help="number of updates to the disparity field in each forward pass.")
    parser.add_argument('--wdecay', type=float, default=.00001, help="Weight decay in optimizer.")

    # Validation parameters
    parser.add_argument('--valid_iters', type=int, default=32, help='number of flow-field updates during validation forward pass')
    parser.add_argument('--encoder', type=str, default='vitl', choices=['vits', 'vitb', 'vitl', 'vitg'])
    # Architecure choices
    parser.add_argument('--corr_levels', type=int, default=2, help="number of levels in the correlation pyramid")
    parser.add_argument('--corr_radius', type=int, default=4, help="width of the correlation pyramid")
    parser.add_argument('--n_downsample', type=int, default=2, help="resolution of the disparity field (1/2^K)")
    parser.add_argument('--n_gru_layers', type=int, default=3, help="number of hidden GRU levels")
    parser.add_argument('--hidden_dims', nargs='+', type=int, default=[128]*3, help="hidden state and context dimensions")
    parser.add_argument('--max_disp', type=int, default=192, help="max disp range")
    # parser.add_argument('--s_disp_range', type=int, default=48, help="max disp of small disparity-range geometry encoding volume")
    # parser.add_argument('--m_disp_range', type=int, default=96, help="max disp of medium disparity-range geometry encoding volume")
    # parser.add_argument('--l_disp_range', type=int, default=192, help="max disp of large disparity-range geometry encoding volume")
    # parser.add_argument('--s_disp_interval', type=int, default=1, help="disp interval of small disparity-range geometry encoding volume")
    # parser.add_argument('--m_disp_interval', type=int, default=2, help="disp interval of medium disparity-range geometry encoding volume")
    # parser.add_argument('--l_disp_interval', type=int, default=4, help="disp interval of large disparity-range geometry encoding volume")

    # Data augmentation
    parser.add_argument('--img_gamma', type=float, nargs='+', default=None, help="gamma range")
    parser.add_argument('--saturation_range', type=float, nargs='+', default=[0, 1.4], help='color saturation')
    parser.add_argument('--do_flip', default=False, choices=['h', 'v'], help='flip the images horizontally or vertically')
    parser.add_argument('--spatial_scale', type=float, nargs='+', default=[-0.4, 0.8], help='re-scale the images randomly')
    parser.add_argument('--noyjitter', action='store_true', help='don\'t simulate imperfect rectification')
    args = parser.parse_args()

    torch.manual_seed(666)
    np.random.seed(666)
    
    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s %(levelname)-8s [%(filename)s:%(lineno)d] %(message)s')

    Path(args.logdir).mkdir(exist_ok=True, parents=True)

    train(args)
