import sys
sys.path.append('core')
import os
import argparse
import glob
import numpy as np
import torch
import matplotlib as mpl
from tqdm import tqdm
from pathlib import Path
from igev_stereo import IGEVStereo
from core.utils.utils import InputPadder
from PIL import Image
from matplotlib import pyplot as plt
import os
import cv2

DEVICE = 'cuda'
os.environ['CUDA_VISIBLE_DEVICES'] = '0'
starter, ender = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)

def load_image(imfile):
    img = np.array(Image.open(imfile)).astype(np.uint8)[..., :3]
    img = torch.from_numpy(img).permute(2, 0, 1).float()
    return img[None].to(DEVICE)

def draw_disparity(self, disparity_map, colormap, enhance=True, percentile=0.01):
        if isinstance(disparity_map, torch.Tensor):
            disparity_map = disparity_map.numpy()
        norm_disparity_map = ((disparity_map - np.min(disparity_map)) / (np.max(disparity_map) - np.min(disparity_map)))
        # img = cv2.applyColorMap(cv2.convertScaleAbs(norm_disparity_map, 1), cv2.COLORMAP_VIRIDIS)
        # norm_disparity_map = np.clip(disparity_map / 192, 0, 1)
        if enhance:
            norm_disparity_map = torch.from_numpy(norm_disparity_map)
            log_disp = torch.log(1.0 - norm_disparity_map + 1e-8)  # Increase visualization contrast
            to_use = log_disp.view(-1)

            mi, ma = torch.quantile(to_use, torch.FloatTensor([percentile, 1-percentile]).to(to_use.device))
            log_disp = (log_disp - mi) / (ma - mi + 1e-10)
            log_disp = torch.clip(1.0 - log_disp, 0, 1)
            norm_disparity_map = log_disp.numpy()
        if isinstance(colormap, str):
            cm = mpl.colormaps[colormap]
            img = cm(norm_disparity_map)
            img = (255 * img).astype(np.uint8)
        else:
            # img = cv2.applyColorMap(cv2.convertScaleAbs(norm_disparity_map, 1), colormap)

             img = cv2.applyColorMap(norm_disparity_map, cv2.COLORMAP_JET)
        self.output.ax.imshow(img, extent=(0, self.output.width, self.output.height, 0))
        return self.output

def demo(args):
    model = torch.nn.DataParallel(IGEVStereo(args), device_ids=[0])

    model.load_state_dict(torch.load(args.restore_ckpt))

    model = model.module
    model.to(DEVICE)
    model.eval()

    # checkpoint = torch.load(args.restore_ckpt)
    # ckpt = dict()
    # if 'state_dict' in checkpoint.keys():
    #     checkpoint = checkpoint['state_dict']
    # for key in checkpoint:
    #     ckpt['module.' + key] = checkpoint[key]

    # model.load_state_dict(ckpt, strict=True)

    # model = model.module
    # model.to(DEVICE)
    # model.eval()

    output_directory = Path(args.output_directory)
    output_directory.mkdir(parents=True, exist_ok=True)

    with torch.no_grad():
        datasets_path = '/media/aszitao/new/ZF/datasets/two_view_training'
        for dir_name in os.listdir(datasets_path):
            dir_path = os.path.join(datasets_path, dir_name)
            if not os.path.isdir(dir_path):
                continue

            output_file_path = os.path.join(output_directory, dir_name + '.pfm')
            timing_file_path = os.path.join(output_directory, dir_name + '.txt')

            if os.path.isfile(output_file_path) and os.path.isfile(timing_file_path):
                print('Skipping since output already present: ' + dir_name)
                continue
            
            print('Processing: ' + dir_name)
            
            # Assemble call.
            left_image_path = os.path.join(dir_path, 'im0.png')
            right_image_path = os.path.join(dir_path, 'im1.png')
            image1 = load_image(left_image_path)
            image2 = load_image(right_image_path)

            padder = InputPadder(image1.shape, divis_by=32)
            image1, image2 = padder.pad(image1, image2)

            starter.record()
            disp = model(image1, image2, iters=args.valid_iters, test_mode=True)

            ender.record()
            torch.cuda.synchronize()
            curr_time = starter.elapsed_time(ender)

            disp = disp.cpu().numpy()
            disp = padder.unpad(disp).squeeze()
            with open(output_file_path, 'wb') as f:
                H, W = disp.shape
                headers = ["Pf\n", f"{W} {H}\n", "-1\n"]
                for header in headers:
                    f.write(str.encode(header))
                array = np.flip(disp, axis=0).astype(np.float32)
                f.write(array.tobytes())

            with open(timing_file_path, 'wb') as f:
                time ='runtime %.2f' % (curr_time / 1000)
                f.write(str.encode(time))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--restore_ckpt', help="restore checkpoint", default="/media/aszitao/new/ZF/ETH.pth")
    parser.add_argument('--save_numpy', action='store_true', help='save output as numpy arrays')
    parser.add_argument('-l', '--left_imgs', help="path to all first (left) frames", default=None)
    parser.add_argument('-r', '--right_imgs', help="path to all second (right) frames", default=None)
    parser.add_argument('--output_directory', help="directory to save output", default="output/two_view_test/disp")
    parser.add_argument('--mixed_precision', action='store_true', help='use mixed precision')
    parser.add_argument('--precision_dtype', default='float32', choices=['float16', 'bfloat16', 'float32'],
                        help='Choose precision type: float16 or bfloat16 or float32')
    parser.add_argument('--valid_iters', type=int, default=32, help='number of flow-field updates during forward pass')
    parser.add_argument('--encoder', type=str, default='vitl', choices=['vits', 'vitb', 'vitl', 'vitg'])
    # Architecture choices
    parser.add_argument('--hidden_dims', nargs='+', type=int, default=[128] * 3,
                        help="hidden state and context dimensions")
    parser.add_argument('--corr_levels', type=int, default=2, help="number of levels in the correlation pyramid")
    parser.add_argument('--corr_radius', type=int, default=4, help="width of the correlation pyramid")
    parser.add_argument('--n_downsample', type=int, default=2, help="resolution of the disparity field (1/2^K)")
    parser.add_argument('--n_gru_layers', type=int, default=3, help="number of hidden GRU levels")
    parser.add_argument('--max_disp', type=int, default=192, help="max disp range")
    args = parser.parse_args()

    demo(args)
